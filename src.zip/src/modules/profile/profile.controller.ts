import { Body, Controller, Post } from '@nestjs/common';
import { RegistrationRequestDto } from './dto/registrations.request.dto';
import { ProfileService } from './profile.service';

@Controller('v1/profile_registration')
export class ProfileController {
  constructor(private profileservice: ProfileService){}

    @Post()
    async profileRegister(@Body() requestDto: RegistrationRequestDto):Promise<any>{
        return await this.profileservice.profileRegister(requestDto);
    }
}